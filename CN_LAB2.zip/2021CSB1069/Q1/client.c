#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 12348

void upload_file(int client_socket, const char* file_name) {
    char buffer[1024];
    ssize_t bytes_received;
    
    recv(client_socket, buffer, sizeof(buffer), 0);

    FILE* file = fopen(file_name, "rb");
    if (!file) {
        perror("Error opening file for reading");
        return;
    }

    while ((bytes_received = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        send(client_socket, buffer, bytes_received, 0);
    }

    printf("File %s uploaded successfully.\n", file_name);
    fclose(file);
}

void download_file(int client_socket, const char* file_name) {
    char buffer[1024];
    ssize_t bytes_received;
    send(client_socket, file_name, strlen(file_name), 0);
    FILE* file = fopen(file_name, "wb");
    while ((bytes_received = recv(client_socket, buffer, sizeof(buffer), 0)) > 0) {
        fwrite(buffer, 1, bytes_received, file);
    }
    printf("File %s downloaded successfully.\n", file_name);
    fclose(file);
}

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Server IP address
    server_addr.sin_port = htons(PORT);
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error connecting to server");
        close(client_socket);
        exit(EXIT_FAILURE);
    }
    upload_file(client_socket, "client.txt");
    download_file(client_socket, "server.txt");

    close(client_socket);

    return 0;
}


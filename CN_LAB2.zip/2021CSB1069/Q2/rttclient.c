#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>

#define PORT 12345

void calculate_rtt(struct timeval start_time, struct timeval end_time) {
    double rtt;
    rtt = ((end_time.tv_sec - start_time.tv_sec) * 1000.0) + ((end_time.tv_usec - start_time.tv_usec) / 1000.0);
    printf("Round-Trip Time (RTT): %.2f ms\n", rtt);
}

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    struct timeval start_time, end_time;
    char message[] = "Ping";

    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Server IP address
    server_addr.sin_port = htons(PORT);

    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error connecting to server");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    gettimeofday(&start_time, NULL);
    send(client_socket, message, sizeof(message), 0);
    recv(client_socket, message, sizeof(message), 0);
    gettimeofday(&end_time, NULL);
    calculate_rtt(start_time, end_time);
    close(client_socket);

    return 0;
}


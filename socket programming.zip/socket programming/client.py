# Client
import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('127.0.0.1', 8888))

# Receive the message to be echoed from the server
message_to_echo = client_socket.recv(1024)
print(f"Server says: {message_to_echo.decode('utf-8')}")

# Send the echoed message back to the server
client_socket.send(message_to_echo)

client_socket.close()

# Server
import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('127.0.0.1', 8888))
server_socket.listen(5)

print("Server listening on port 8888...")

while True:
    client_socket, client_address = server_socket.accept()
    print(f"Connection from {client_address}")

    # Wait for user input to get the message to be echoed
    message = input("Enter the message to be echoed: ")

    # Send the message to the client
    client_socket.send(message.encode('utf-8'))

    # Receive the echoed message from the client
    echoed_message = client_socket.recv(1024)
    print(f"Server received: {echoed_message.decode('utf-8')}")

    client_socket.close()

#include <iostream>
#include <pcap.h>
#include <netinet/ether.h>
#include <cstring>
#include <cstdlib>
#include <stdlib.h>

using namespace std;


void packetHandler(u_char* userData, const struct pcap_pkthdr* pkthdr, const u_char* packetData) 
{
    struct ether_header* ethHeader = (struct ether_header*)packetData;
    uint16_t etherType = ntohs(ethHeader->ether_type);

    const u_char* ipHeader = packetData + sizeof(struct ether_header);
    uint8_t ipProtocol = ipHeader[9];
    
    if (etherType == ETHERTYPE_IP) {
    
        if(ipProtocol==IPPROTO_UDP)
         {
                cout << "DHCP Packet captured! Size: " << pkthdr->len << " bytes" << endl;
          }
        else if(ipProtocol==IPPROTO_ICMP)
         {
                cout << "ICMP Packet captured! Size: " << pkthdr->len << " bytes" << endl;
         }
         else if(ipProtocol==IPPROTO_TCP)
         {
           
                cout << "TCP Packet captured! Size: " << pkthdr->len << " bytes" << endl;
         }
            
    }
    pcap_dumper_t* dumper = (pcap_dumper_t*)userData;
    
    pcap_dump((u_char*)dumper, pkthdr, packetData);
}

int main() {
    char* dev; 
    char errbuf[PCAP_ERRBUF_SIZE]; 

    dev = pcap_lookupdev(errbuf);
    if (dev == nullptr) {
        cerr << "Error finding device: " << errbuf << endl;
        return 1;
    }

    pcap_t* handle = pcap_open_live(dev, BUFSIZ, 1, 1000, errbuf);
    if (handle == nullptr) {
        cerr << "Error opening device: " << errbuf << endl;
        return 1;
    }

    cout << "Enter the protocol to capture (DHCP, ICMP, TCP): ";
    string protocol;
    cin >> protocol;

    string filter_exp;
    if (protocol == "DHCP") {
        filter_exp = "udp port 67 or udp port 68";
    } else if (protocol == "ICMP") {
        filter_exp = "icmp";
    } else if (protocol == "TCP") {
        filter_exp = "tcp";
    } else {
        cerr << "Invalid protocol specified" << endl;
        return 1;
    }

    struct bpf_program fp;
    if (pcap_compile(handle, &fp, filter_exp.c_str(), 0, PCAP_NETMASK_UNKNOWN) == -1) 
    {
        cerr << "Error compiling filter expression" << endl;
        return 1;
    }
    if (pcap_setfilter(handle, &fp) == -1) 
    {
        cerr << "Error setting filter" << endl;
        return 1;
    }
    pcap_dumper_t* dumper = pcap_dump_open(handle, "SpecialpacketsQ2.pcap");
    
    if (dumper == nullptr) 
    {
            cerr << "Error opening pcap file for writing" << endl;
            return 1;
    }
    

    cout << "Enter the number of packets to capture: ";
    int num_packets;
    cin >> num_packets;

    pcap_loop(handle, num_packets, packetHandler, (u_char*)dumper);
    pcap_dump_close(dumper); 
    pcap_close(handle);

    return 0;
}


#include <iostream>
#include <pcap.h>
#include <netinet/ether.h>
#include <stdlib.h>

using namespace std;

void packetHandler(u_char* userData, const struct pcap_pkthdr* pkthdr, const u_char* packetData) {

    struct ether_header* ethHeader = (struct ether_header*)packetData;
    uint16_t etherType = ntohs(ethHeader->ether_type);

    cout << "Packet captured! Size: " << pkthdr->len << " bytes ";
    if (etherType == ETHERTYPE_IP) {
        cout << "Type: IPv4" << endl;
    } else if (etherType == ETHERTYPE_IPV6) {
        cout << "Type: IPv6" << endl;
    } else if (etherType == ETHERTYPE_ARP) {
        cout << "Type: ARP" << endl;
    } else {
        cout << "Type: Unknown" << endl;
    }

    pcap_dumper_t* dumper = (pcap_dumper_t*)userData;
    
    pcap_dump((u_char*)dumper, pkthdr, packetData);
}

int main() {
    char* avail_device;
    char device_buffer[PCAP_ERRBUF_SIZE];
    avail_device = pcap_lookupdev(device_buffer);

    if (avail_device == nullptr) {
        cerr << "Error finding device to connect: " << device_buffer << endl;
        return 1;
    } else {
        pcap_t* open_device = pcap_open_live(avail_device, BUFSIZ, 1, 1000, device_buffer);
        if (open_device == nullptr) {
            cerr << "Error opening device: " << device_buffer << endl;
            return 1;
        }
        pcap_dumper_t* dumper = pcap_dump_open(open_device, "AllpacketsQ1.pcap");
        if (dumper == nullptr) {
            cerr << "Error opening pcap file for writing" << endl;
            return 1;
        }
	cout << "Enter the number of packets to capture: ";
    	int num_packets;
    	cin >> num_packets;
        pcap_loop(open_device, num_packets, packetHandler, (u_char*)dumper);

        pcap_dump_close(dumper); 

        pcap_close(open_device);
    }

    return 0;
}

